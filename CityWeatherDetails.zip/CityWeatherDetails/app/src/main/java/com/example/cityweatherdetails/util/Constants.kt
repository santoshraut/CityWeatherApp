package com.example.cityweatherdetails.util

class Constants {
    companion object {
        const val BASE_URL = "https://api.openweathermap.org/data/2.5/"
        const val APP_ID = "5c72fb4bb0f9e8e3af664fb1348b21d4"
    }
}